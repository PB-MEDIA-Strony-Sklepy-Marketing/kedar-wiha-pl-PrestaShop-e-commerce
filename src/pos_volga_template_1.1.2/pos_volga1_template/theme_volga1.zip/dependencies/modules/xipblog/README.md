# xipblog
This is blog module for prestashop. It has many many amazing features. Standard, Gallery, Audio, Video post format available on this blog module. 

# Child Modules

If you can display xipblog posts on your theme, just installed bellow modules ....

* <a target="_blank" href="https://github.com/xpert-idea/xipblogdisplayposts">xipblogdisplayposts</a>

# Demo
Please <a href="http://xpert-idea.com/prestashop/jakiro/demo/nine/en/">click here </a> to see the blog demo.

# Documentation
Please <a href="https://www.youtube.com/channel/UC0TS71jcnQ7pJJMTqluBI3Q">click here </a> to follow our youtube channel for the blog module documentation.

# Important Notice
If you are Theme author, you can use and include this Modules as free to build themes for sale.

# Support
If you fetch any issue to use our blog module please go to our site and contact with us by comment your issue on this <a href="http://xpert-idea.com/2016/10/15/powerfull-prestashop-blog-module-is-free-from-now/">post.</a>

# Who We Are

We are author of themeforest, Please <a href="https://themeforest.net/user/xpert-idea/portfolio?ref=xpert-idea">click here</a> to see our profile . Also you can visit our website. http://xpert-idea.com/

You can also visit our premimum prestashop themes:
* <a href="https://themeforest.net/item/jakiro-fashion-shop-prestashop-theme/14100073?ref=xpert-idea">Jakiro Prestashop Theme </a>
* <a href="https://themeforest.net/item/great-store-ecommerce-prestashop-theme/18303739?ref=xpert-idea">Great Store Prestashop Theme</a>
