<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{posmegamenu}prestashop>posmegamenu_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{posmegamenu}prestashop>posmegamenu_852dd1897617ff22ca0b33de91271c4e'] = 'Top offset:';
$_MODULE['<{posmegamenu}prestashop>posmegamenu_06933067aafd48425d67bcb01bba5cb6'] = 'Update';
