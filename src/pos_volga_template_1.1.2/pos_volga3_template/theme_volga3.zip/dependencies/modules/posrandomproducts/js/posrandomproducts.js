$(document).ready(function() {
	var $randomSlideConf = $('.pos_random_product');
	var items       = parseInt($randomSlideConf.attr('data-items'));
	var speed     	= parseInt($randomSlideConf.attr('data-speed'));
	var autoPlay    = parseInt($randomSlideConf.attr('data-autoplay'));
	var time    	= parseInt($randomSlideConf.attr('data-time'));
	var arrow       = parseInt($randomSlideConf.attr('data-arrow'));
	var pagination  = parseInt($randomSlideConf.attr('data-pagination'));
	var move        = parseInt($randomSlideConf.attr('data-move'));
	var pausehover  = parseInt($randomSlideConf.attr('data-pausehover'));
	var md          = parseInt($randomSlideConf.attr('data-md'));
	var sm          = parseInt($randomSlideConf.attr('data-sm'));
	var xs          = parseInt($randomSlideConf.attr('data-xs'));
	var xxs         = parseInt($randomSlideConf.attr('data-xxs'));
	
	if(autoPlay==1) {
		if(time){
			autoPlay = time;
		}else{
			autoPlay = '3000';
		}
	}else{
		autoPlay = false;
	}
	if(pausehover){pausehover = true}else{pausehover=false}
	if(move){move = false}else{move=true}
	if(arrow){arrow =true}else{arrow=false}
	if(pagination==1){pagination = true}else{pagination=false}

	var randomSlide = $(".pos_random_product .randomproductslide");
	randomSlide.owlCarousel({
		autoplay : autoPlay ,
		smartSpeed: speed,
		autoplayHoverPause: pausehover,
		addClassActive: true,
		scrollPerPage: move,
		nav : arrow,
		dots : pagination,
		responsiveClass:true,		
		responsive:{
			0:{
				items:xxs,
			},
			480:{
				items:xs,
			},
			768:{
				items:sm,
				nav:false,
			},
			992:{
				items:md,
			},
			1200:{
				items:items,
			}
		}
	});
});

