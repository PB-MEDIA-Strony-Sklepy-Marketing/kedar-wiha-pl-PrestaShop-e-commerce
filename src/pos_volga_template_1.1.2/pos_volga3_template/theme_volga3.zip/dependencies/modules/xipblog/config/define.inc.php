<?php
if (!defined('xipblog_dir')) {
	define('xipblog_dir', _PS_MODULE_DIR_.'xipblog/');
}
if (!defined('xipblog_theme_dir')) {
	define('xipblog_theme_dir', _PS_MODULE_DIR_.'xipblog/views/templates/front/');
}
if (!defined('xipblog_uri')) {
	define('xipblog_uri', __PS_BASE_URI__.'modules/xipblog/');
}
if (!defined('xipblog_img_dir')) {
	define('xipblog_img_dir', _PS_MODULE_DIR_.'xipblog/img/');
}
if (!defined('xipblog_img_uri')) {
	define('xipblog_img_uri', __PS_BASE_URI__.'modules/xipblog/img/');
}
if (!defined('xipblog_css_dir')) {
	define('xipblog_css_dir', _PS_MODULE_DIR_.'xipblog/css/');
}
if (!defined('xipblog_css_uri')) {
	define('xipblog_css_uri', __PS_BASE_URI__.'modules/xipblog/css/');
}
if (!defined('xipblog_js_dir')) {
	define('xipblog_js_dir', _PS_MODULE_DIR_.'xipblog/js/');
}
if (!defined('xipblog_js_uri')) {
	define('xipblog_js_uri', __PS_BASE_URI__.'modules/xipblog/js/');
}
if (!defined('xipblog_tpl_dir')) {
	define('xipblog_tpl_dir','xipblog/views/templates/front/');
}